from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    SETTING_FETCH_EVERY_X  = 30000
    SETTING_AUTO_RELOAD    = 30001
    SETTING_FILES_DIR      = 30002
    ADD_EPG                = 30003
    ADD_PLAYLIST           = 30004
    MERGE_NOW              = 30005
    DELETE_SOURCE          = 30006
    CONFIRM_DELETE_SOURCE  = 30007
    MERGE_STARTED          = 30008
    NO_OUTPUT_DIR          = 30009
    PLAYLISTS              = 30010
    EPGS                   = 30011
    CHOOSE                 = 30012
    REMOTE_PATH            = 30013
    LOCAL_PATH             = 30014
    URL                    = 30015
    BROWSE_FILE            = 30016
    STANDARD_FILE          = 30017
    GZIPPED_FILE           = 30018
    
    MERGE_COMPLETE         = 30025
    ADDON_SOURCE           = 30026
    NO_ADDONS              = 30027
    SETUP_IPTV_SIMPLE      = 30028
    NO_IPTV_SIMPLE         = 30029
    SETUP_COMPLETE         = 30030
    CONFIRM_IPTV_SETUP     = 30031
    IPTV_SETUP_ABOUT       = 30032
    CHANNEL_MANAGER        = 30033
    NO_CHANNELS            = 30034
    NO_CHANNELS_MSG        = 30035
    NO_CHANNEL_NAME        = 30036

_ = Language()