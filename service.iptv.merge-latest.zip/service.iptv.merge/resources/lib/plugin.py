import os

import xbmc, xbmcaddon

from matthuisman import plugin, settings, gui
from matthuisman.constants import ADDON_ID, ADDON_PROFILE
from matthuisman.exceptions import PluginError

from .language import _
from .models import Source, Channel
from .constants import FORCE_RUN_FLAG, IPTV_SIMPLE_ID, PLAYLIST_FILE_NAME, EPG_FILE_NAME

@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder()

    folder.add_item(
        label = _(_.PLAYLISTS, _bold=True), 
        path  = plugin.url_for(playlists),
    )

    folder.add_item(
        label = _(_.EPGS, _bold=True), 
        path  = plugin.url_for(epgs),
    )

    # folder.add_item(
    #     label = _(_.CHANNEL_MANAGER, _bold=True), 
    #     path  = plugin.url_for(channel_manager),
    # )

    folder.add_item(
        label = _.MERGE_NOW, 
        path  = plugin.url_for(merge),
    )

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def channel_manager(**kwargs):
    folder = plugin.Folder(title=_.CHANNEL_MANAGER)

    channels = list(Channel.select().order_by(Channel.chno))
    if not channels:
        raise PluginError(_.NO_CHANNELS_MSG, heading=_.NO_CHANNELS)

    for channel in channels:
        folder.add_item(
            label     = channel.name,
            art       = {'thumb': channel.logo},
            is_folder = False,
            playable  = False,
        )

    return folder

@plugin.route()
def setup(**kwargs):
    if not gui.yes_no(_.IPTV_SETUP_ABOUT, heading=_.CONFIRM_IPTV_SETUP):
        return

    try:
        xbmc.executebuiltin('InstallAddon({})'.format(IPTV_SIMPLE_ID), True)
        addon = xbmcaddon.Addon(IPTV_SIMPLE_ID)
    except:
        raise PluginError(_.NO_IPTV_SIMPLE)

    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format(IPTV_SIMPLE_ID))

    output_dir    = settings.get('output_dir', '').strip() or ADDON_PROFILE
    playlist_path = os.path.normcase(os.path.join(output_dir, PLAYLIST_FILE_NAME))
    epg_path      = os.path.normcase(os.path.join(output_dir, EPG_FILE_NAME))

    playlist = os.path.normcase(addon.getSetting('m3uPath'))
    if playlist and playlist != playlist_path:
        source = Source(item_type=Source.PLAYLIST, path_type=Source.TYPE_LOCAL, path=playlist, file_type=Source.FILE_STANDARD)
        source.save()
    
    playlist = addon.getSetting('m3uUrl')
    if playlist:
        source = Source(item_type=Source.PLAYLIST, path_type=Source.TYPE_REMOTE, path=playlist, file_type=Source.FILE_STANDARD)
        source.save()

    epg = os.path.normcase(addon.getSetting('epgPath'))
    if epg and epg != epg_path:
        source = Source(item_type=Source.EPG, path_type=Source.TYPE_LOCAL, path=epg, file_type=Source.FILE_STANDARD)
        source.save()

    epg = addon.getSetting('epgUrl')
    if epg:
        source = Source(item_type=Source.EPG, path_type=Source.TYPE_REMOTE, path=epg, file_type=Source.FILE_STANDARD)
        source.save()

    addon.setSetting('m3uPathType', '0')
    addon.setSetting('m3uPath', playlist_path)
    addon.setSetting('m3uUrl', '')
    addon.setSetting('m3uCache', 'false')

    addon.setSetting('epgPathType', '0')
    addon.setSetting('epgPath', epg_path)
    addon.setSetting('epgUrl', '')
    addon.setSetting('epgCache', 'false')

    settings.set('output_dir', output_dir)
    settings.setBool('restart_pvr', True)

    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(IPTV_SIMPLE_ID))
    
    gui.ok(_.SETUP_COMPLETE)

@plugin.route()
def playlists(**kwargs):
    folder = plugin.Folder(title=_.PLAYLISTS)
    sources = list(Source.select().where(Source.item_type == Source.PLAYLIST))

    for source in sources:
        item = plugin.Item(
            label = source.label(),
            path = plugin.url_for(edit_source, id=source.id),
            is_folder = False,
            playable = False,
        )

        item.context.append((_.DELETE_SOURCE, 'XBMC.RunPlugin({})'.format(plugin.url_for(delete_source, id=source.id))))

        folder.add_items([item])

    folder.add_item(
        label = _(_.ADD_PLAYLIST, _bold=len(sources) == 0), 
        path  = plugin.url_for(edit_source, type=Source.PLAYLIST),
    )

    return folder

@plugin.route()
def epgs(**kwargs):
    folder = plugin.Folder(title=_.EPGS)
    sources = list(Source.select().where(Source.item_type == Source.EPG))

    for source in sources:
        item = plugin.Item(
            label = source.label(),
            path = plugin.url_for(edit_source, id=source.id),
            is_folder = False,
            playable = False,
        )

        item.context.append((_.DELETE_SOURCE, 'XBMC.RunPlugin({})'.format(plugin.url_for(delete_source, id=source.id))))

        folder.add_items([item])

    folder.add_item(
        label = _(_.ADD_EPG, _bold=len(sources) == 0), 
        path  = plugin.url_for(edit_source, type=Source.EPG),
    )

    return folder

@plugin.route()
def delete_source(id, **kwargs):
    source = Source.get_by_id(id)
    if gui.yes_no(_.CONFIRM_DELETE_SOURCE) and source.delete_instance():
        gui.refresh()

@plugin.route()
def edit_source(id=None, type=None, **kwargs):
    if id:
        source = Source.get_by_id(id)
    else:
        source = Source(item_type=type)

    if source.wizard():
        source.save()
        gui.refresh()

@plugin.route()
def merge(**kwargs):
    if not settings.get('output_dir'):
        raise plugin.PluginError(_.NO_OUTPUT_DIR)

    xbmc.executebuiltin('Skin.SetString({},{})'.format(ADDON_ID, FORCE_RUN_FLAG))
    gui.notification(_.MERGE_STARTED)