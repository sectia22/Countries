import os
import re
import gzip
import shutil
import time
import json
import subprocess

import xml.parsers.expat
from xml.sax.saxutils import escape

import xbmc, xbmcaddon

from matthuisman import settings, userdata, database, gui
from matthuisman.constants import ADDON_ID, SESSION_CHUNKSIZE, ADDON_DEV
from matthuisman.log import log
from matthuisman.session import Session
from matthuisman.exceptions import Error
from matthuisman.util import remove_file, hash_6

from .constants import FORCE_RUN_FLAG, PLAYLIST_FILE_NAME, EPG_FILE_NAME, METHOD_PLAYLIST, METHOD_EPG, MERGE_SETTING_FILE, IPTV_SIMPLE_ID
from .models import Source, Channel
from .language import _

monitor  = xbmc.Monitor()

def call(cmd):
    log.debug('Subprocess call: {}'.format(cmd))
    return subprocess.call(cmd)

def find_gz():
    log.debug('Searching for Gzip binary...')

    for gzbin in ['/bin/gzip', '/usr/bin/gzip', '/usr/local/bin/gzip', '/system/bin/gzip']:
        if os.path.exists(gzbin):
            log.debug('Gzip binary found: {}'.format(gzbin))
            return gzbin
    
    return None

def gzip_extract(in_path):
    log.debug('Gzip Extracting: {}'.format(in_path))

    out_path = in_path + '.extract'

    try:
        with open(out_path, 'wb') as f_out, gzip.open(in_path, 'rb') as f_in:
            shutil.copyfileobj(f_in, f_out, length=SESSION_CHUNKSIZE)
    except IOError:
        log.debug('Failed to extract using python gzip (Known Kodi Android bug)')
        remove_file(out_path)
    else:
        shutil.move(out_path, in_path)
        return

    gzbin = find_gz()
    if not gzbin:
        remove_file(in_path)
        raise Error('No Gzip binary found')

    gz_path = in_path + '.gz'
    remove_file(gz_path)

    shutil.move(in_path, gz_path)
    call([gzbin, '-d', gz_path])
    
    if os.path.exists(gz_path):
        remove_file(gz_path)
        raise Error('Failed to extract: {}'.format(gz_path))

def call_addon_method(addon_id, method_name, in_path):
    addon      = xbmcaddon.Addon(addon_id)
    addon_path = xbmc.translatePath(addon.getAddonInfo('path')).decode("utf-8")
    merge_path = os.path.join(addon_path, MERGE_SETTING_FILE)

    with open(merge_path) as f:
        data = json.load(f)

    plugin_url = data[method_name].get('url', 'plugin://$ID/?_={}&output=$FILE'.format(method_name)).replace('$ID', addon.getAddonInfo('id')).replace('$FILE', in_path)
    timeout    = int(data[method_name].get('timeout', 10))

    remove_file(in_path)
    xbmc.executebuiltin('XBMC.RunPlugin({})'.format(plugin_url))

    for i in range(timeout):
        if os.path.exists(in_path) or monitor.waitForAbort(1):
            break

    if not os.path.exists(in_path):
        raise Error('Addon Failed')

    return in_path

def process_file(item, method_name, output_dir):
    in_path = os.path.join(output_dir, '.iptv_merge_tmp')
    remove_file(in_path)

    if item.path_type == Source.TYPE_ADDON:
        return call_addon_method(item.path, method_name, in_path)

    elif item.path_type == Source.TYPE_REMOTE:
        log.debug('Downloading: {} > {}'.format(item.path, in_path))
        Session().chunked_dl(item.path, in_path)
        
    elif item.path_type == Source.TYPE_LOCAL:
        path = xbmc.translatePath(item.path)
        if not os.path.exists(path):
            raise Error('{} does not exist'.format(path))
        
        log.debug('Copying local file: {} > {}'.format(path, in_path))
        shutil.copyfile(path, in_path)

    if item.file_type == Source.FILE_GZIP:
        gzip_extract(in_path)

    return in_path

def process_channels(channels):
    Channel.truncate()

    for channel in channels:
        Channel.get_or_create(
            checksum = channel['checksum'],
            url      = channel['url'],
            tvg_id   = channel.get('tvg-id'),
            name     = channel.get('tvg-name'),
            chno     = channel.get('tvg-chno'),
            logo     = channel.get('tvg-logo'),
            group    = channel.get('group-title'),
        )

def merge_playlists(playlists, output_dir):
    log.debug('Merging {} Playlists...'.format(len(playlists)))

    merged_path = os.path.join(output_dir, '.iptv_merge_playlist')

    with open(merged_path, 'wb') as outfile:
        outfile.write(b'#EXTM3U\n')

        for playlist in playlists:
            file_path = process_file(playlist, METHOD_PLAYLIST, output_dir)
            line = ''

            log.debug('Processing: {}'.format(playlist.path))
            with open(file_path) as infile:
                for line in infile:
                    line = line.strip() + '\n'

                    if line.startswith('#EXTM3U'):
                        continue

                    outfile.write(line)

            remove_file(file_path)

    log.debug('Merging Playlists Done')

    return merged_path

# def merge_playlists(playlists, output_dir):
#     log.debug('Merging {} Playlists...'.format(len(playlists)))

#     merged_path = os.path.join(output_dir, '.iptv_merge_playlist')

#     channels = []
#     found    = None
#     channel_count = 1

#     for playlist in playlists:
#         file_path = process_file(playlist, METHOD_PLAYLIST, output_dir)
#         line = ''

#         log.debug('Processing: {}'.format(playlist.path))
#         with open(file_path) as infile:
#             for line in infile:
#                 line = line.strip()
                
#                 if not line or line.startswith('#EXTM3U'):
#                     continue

#                 if line.startswith('#EXTINF'):
#                     found = line
#                 elif found:
#                     data = {'url': line, 'checksum': hash_6(found), 'tvg-name': found.rsplit(',')[-1]}

#                     for key, value in re.findall('([\w-]+)="([^"]*)"', found):
#                         data[key] = value.strip()

#                     if 'tvg-chno' not in data:
#                         data['tvg-chno'] = channel_count
#                         channel_count += 1

#                     channels.append(data)
#                     found = None

#         remove_file(file_path)

#     process_channels(channels)

#     with open(merged_path, 'wb') as outfile:
#         outfile.write(b'#EXTM3U')

#         for channel in Channel.select().where(Channel.hidden==False).order_by(Channel.chno):
#             outfile.write(b'\n\n#EXTINF:-1 tvg-id="{id}" tvg-chno="{chno}" group-title="{group}" tvg-name="{name}" tvg-logo="{logo}",{name}\n{url}'.format(
#                 id = channel.tvg_id.encode('utf-8'), chno = channel.chno, group = channel.group.encode('utf-8'), name = channel.name.encode('utf-8'), logo = channel.logo.encode('utf-8'), url = channel.url.encode('utf-8'),
#             ))

#     log.debug('Merging Playlists Done')

#     return merged_path

def merge_epgs(epgs, output_dir):
    log.debug('Merging {} EPGs...'.format(len(epgs)))

    merged_path = os.path.join(output_dir, '.iptv_merge_epg')
    ignore_tags = ['tv',]

    with open(merged_path, 'wb') as outfile:
        outfile.write('<?xml version="1.0" encoding="utf-8" ?>\n<tv generator-info-name="{}">'.format(ADDON_ID))

        def attrs_s(attrs):
            l = ['']
            for i in range(0,len(attrs), 2):
                l.append('{}="{}"'.format(attrs[i].encode('utf-8'), escape(attrs[i+1]).encode('utf-8')))
            return ' '.join(l)

        def char_data(data):
            data = data.replace('&', '&amp;')
            data = data.replace('<', '&lt;')
            if data == '>':
                data = '&gt;'
            outfile.write(data.encode('utf-8'))

        def end_element(name):
            if name in ignore_tags:
                return

            outfile.write('</{}>'.format(name.encode('utf-8')))

        def start_element(name, attrs):
            if name in ignore_tags:
                return

            outfile.write('<{}{}>'.format(name.encode('utf-8'), attrs_s(attrs)))

        for epg in epgs:
            file_path = process_file(epg, METHOD_EPG, output_dir)

            p = xml.parsers.expat.ParserCreate()
            p.ordered_attributes = 1
            p.StartElementHandler = start_element
            p.EndElementHandler = end_element
            p.CharacterDataHandler = char_data

            log.debug('Processing: {}'.format(epg.path))
            with open(file_path, 'rt') as infile:
                while True:
                    chunk = infile.read(SESSION_CHUNKSIZE)
                    
                    if len(chunk) < SESSION_CHUNKSIZE:
                        p.Parse(chunk, 1)
                        break
 
                    p.Parse(chunk)

            remove_file(file_path)

        outfile.write('</tv>')

    log.debug('Merging EPGs Done')

    return merged_path

def run_merge():
    output_dir = xbmc.translatePath(settings.get('output_dir'))
    if not os.path.isdir(output_dir):
        log.debug('No output directory set')
        return

    database.connect()

    try:
        playlists    = list(Source.select().where(Source.item_type == Source.PLAYLIST))
        epgs         = list(Source.select().where(Source.item_type == Source.EPG))

        playlist_path = merge_playlists(playlists, output_dir)
        epg_path      = merge_epgs(epgs, output_dir)
    finally:
        database.close()

    shutil.move(playlist_path, os.path.join(output_dir, PLAYLIST_FILE_NAME))
    shutil.move(epg_path, os.path.join(output_dir, EPG_FILE_NAME))

def start():
    restart_queued = False

    while not monitor.waitForAbort(5):
        forced = ADDON_DEV or xbmc.getInfoLabel('Skin.String({})'.format(ADDON_ID)) == FORCE_RUN_FLAG
        if forced:
            xbmc.executebuiltin('Skin.SetString({},)'.format(ADDON_ID))

        if forced or time.time() - userdata.get('last_run', 0) > settings.getInt('reload_time_mins', 10) * 60:
            try:
                run_merge()
            except Exception as e:
                result = False
                log.exception(e)
            else:
                result = True

            userdata.set('last_run', int(time.time()))

            if result:
                if not restart_queued:
                    restart_queued = int(time.time())

                if forced:
                    gui.notification(_.MERGE_COMPLETE)

            elif forced:
                gui.exception()

        if not restart_queued or not settings.getBool('restart_pvr', False):
            restart_queued = False
            continue

        if forced or (not xbmc.getCondVisibility('Pvr.IsPlayingTv') and not xbmc.getCondVisibility('Pvr.IsPlayingRadio')) or time.time() - restart_queued > settings.getInt('max_restart_mins'):
            restart_queued = False

            xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format(IPTV_SIMPLE_ID))
            time.sleep(1)
            xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(IPTV_SIMPLE_ID))

        if ADDON_DEV:
            break