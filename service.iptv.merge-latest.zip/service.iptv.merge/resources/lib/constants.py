FORCE_RUN_FLAG      = '_force_run'
PLAYLIST_FILE_NAME  = 'playlist.m3u8'
EPG_FILE_NAME       = 'epg.xml'

IPTV_SIMPLE_ID      = 'pvr.iptvsimple'
MERGE_SETTING_FILE  = '.iptv_merge'
METHOD_PLAYLIST     = 'playlist'
METHOD_EPG          = 'epg'