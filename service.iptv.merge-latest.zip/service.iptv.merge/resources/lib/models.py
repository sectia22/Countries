import os
import json

import xbmc, xbmcgui, xbmcaddon

from matthuisman import peewee, database, gui
from matthuisman.exceptions import Error

from .constants import MERGE_SETTING_FILE, METHOD_PLAYLIST, METHOD_EPG
from .language import _

class Channel(database.Model):
    tvg_id   = peewee.CharField(null=True)
    checksum = peewee.CharField()
    url      = peewee.TextField()
    name     = peewee.TextField(null=True)
    chno     = peewee.IntegerField(index=True, default=0)
    logo     = peewee.TextField(null=True)
    group    = peewee.TextField(null=True)
    hidden   = peewee.BooleanField(index=True, default=False)

    class Meta:
        primary_key = peewee.CompositeKey('tvg_id', 'checksum')

class Source(database.Model):
    PLAYLIST = 0
    EPG = 1

    TYPE_REMOTE = 0
    TYPE_LOCAL  = 1
    TYPE_ADDON  = 2

    FILE_STANDARD = 0
    FILE_GZIP     = 1

    item_type     = peewee.IntegerField()
    path_type     = peewee.IntegerField()
    path          = peewee.TextField()
    file_type     = peewee.IntegerField(null=True)

    def label(self):
        if self.path_type == self.TYPE_ADDON:
            try:
                return '{} ({})'.format(xbmcaddon.Addon(self.path).getAddonInfo('name'), self.path)
            except:
                return self.path
        else:
            return self.path

    def wizard(self):
        types   = [self.TYPE_REMOTE, self.TYPE_LOCAL, self.TYPE_ADDON]
        options = [_.REMOTE_PATH, _.LOCAL_PATH, _.ADDON_SOURCE]
        default = self.path_type or self.TYPE_REMOTE

        index   = gui.select(_.CHOOSE, options, preselect=types.index(default))
        if index < 0:
            return False

        self.path_type = types[index]

        if self.path_type == self.TYPE_ADDON:
            addons  = self._get_merge_addons()
            if not addons:
                raise Error(_.NO_ADDONS)

            ids     = [x['id'] for x in addons]
            options = [x['name'] for x in addons]

            try:
                default = ids.index(self.path)
            except ValueError:
                default = 0

            index = gui.select(_.CHOOSE, options, preselect=default)
            if index < 0:
                return False

            self.path      = ids[index]
            self.file_type = self.FILE_STANDARD
            
            return True

        elif self.path_type == self.TYPE_REMOTE:
            self.path = gui.input(_.URL, default=self.path)
        elif self.path_type == self.TYPE_LOCAL:
            self.path = xbmcgui.Dialog().browseSingle(1, _.BROWSE_FILE, self.path or '', '')

        if not self.path:
            return False

        types   = [self.FILE_STANDARD, self.FILE_GZIP]
        options = [_.STANDARD_FILE, _.GZIPPED_FILE]
        default = self.file_type or (self.FILE_GZIP if self.path.endswith('.gz') else self.FILE_STANDARD)

        index   = gui.select(_.CHOOSE, options, preselect=types.index(default))
        if index < 0:
            return False

        self.file_type = types[index]

        return True

    def _get_merge_addons(self):
        addons = []

        payload = {
            'id': 1,
            'jsonrpc': '2.0',
            'method': 'Addons.GetAddons',
            'params': {'installed': True, 'enabled': True, 'type': 'xbmc.python.pluginsource'},
        }

        response = xbmc.executeJSONRPC(json.dumps(payload))
        data     = json.loads(response)

        for row in data['result']['addons']:
            addon      = xbmcaddon.Addon(row['addonid'])
            addon_path = xbmc.translatePath(addon.getAddonInfo('path')).decode("utf-8")
            merge_path = os.path.join(addon_path, MERGE_SETTING_FILE)
            
            if not os.path.exists(merge_path):
                continue

            with open(merge_path) as f:
                data = json.load(f)

            if int(self.item_type) == self.PLAYLIST and METHOD_PLAYLIST not in data:
                continue

            if int(self.item_type) == self.EPG and METHOD_EPG not in data:
                continue

            addons.append({'name': addon.getAddonInfo('name'), 'id': addon.getAddonInfo('id')})

        return addons

database.tables.extend([Source, Channel])